package playwithme.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FriendListDTO {
	private String member_Id;
	private String f_Member_Id;
	private String friendchat_room_num;

}

